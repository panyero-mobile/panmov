<?php
// Redirect to splash.html
header("Location: splash.html");
exit;
?>

